# 73MCT v12 — mobile workflow and learning improvements

This is an updated Android Studio project for the 73MCT floating paper-trading app.

## Included in this build

### Faster Axiom → FOMO handoff
- `OPEN FOMO` copies the currently loaded Solana contract address to the Android clipboard.
- It launches the installed FOMO Android package (`family.fomo.app`) when available.
- If that package is not installed, it opens FOMO Web at `https://fomo.family`.
- FOMO's own mobile Search flow supports pasting a token CA. This build does **not** claim a direct token-page deep link because a public arbitrary-CA deep-link format has not been verified. In FOMO, use Search → Paste if it opens to the app home/search screen.

### Quick workflow
- Recent coins list with saved CA, last-seen MC, liquidity, volume and decision state.
- Fast / Full panel toggle. Fast mode hides optional thesis, custom sell and research details; Full mode restores them.
- Watch and Skip actions with an approximate time-to-decision measurement.
- A skipped-coin summary that reports the highest market-cap multiple observed while 73MCT was tracking that coin. This is not an all-time market high.
- Market activity from DexScreener: 5-minute volume, 5-minute buys/sells, pair age and 5-minute price change when available.

### Holder concentration (best effort)
- Public Solana RPC lookup of the 20 largest token accounts.
- Aggregates token accounts by parsed owner wallet where the RPC provides owner data.
- Displays top-10 and largest-owner concentration as an **estimate based only on the largest 20 accounts**.
- It is not a complete holder scan and does not infer developer, sniper, insider or bundle ownership. Those fields are deliberately not fabricated.

### Paper trading and review
- Liquidity-sensitive slippage estimate layered on top of the configured baseline. It is an educational estimate using pool liquidity, not a guaranteed fill quote or exact DEX AMM simulation.
- `TAKE INITIAL` estimates a sell percentage to recover initial SOL invested, after modeled fees, priority fee and estimated slippage.
- `CLOSE ALL` shortcut while a position is open.
- Optional post-trade mistake tags and insight breakdown by tag.
- Recent-token snapshots at roughly four-second intervals while a coin is loaded, with capped history per coin. The current UI provides a summary, not an interactive scrub/playback chart.

## Not included / known limits

- No verified direct FOMO deep link to an arbitrary token page. Current handoff is clipboard + app launch.
- No Axiom reconnection fix. Axiom is a separate PWA; 73MCT cannot keep its page's WebSocket alive when Android suspends it.
- No complete Axiom-equivalent dev/sniper/insider/bundle analysis.
- No full interactive trade replay, background market-cap alerts, or daily risk-limit engine in this version.
- The user should verify token details and execution conditions independently; holder data and slippage are estimates.

## Build with GitHub Actions

1. Upload the contents of this source ZIP to the root of your GitHub repository, or upload the ZIP itself.
2. Put `.github/workflows/build-apk.yml` at the repository path `.github/workflows/build-apk.yml` (GitHub does not discover a workflow file until it is in that exact repository folder).
3. Commit and push to the default branch, or run **Actions → Build 73MCT Android APK → Run workflow**.
4. Download the artifact named `73MCT-v12-APK` from the completed workflow. It contains `app-debug.apk`.

The workflow installs JDK 17 and Gradle 8.5 on GitHub's runner and runs `gradle assembleDebug`.

## Upgrade / data

The project retains the existing application ID (`com.pocketflip.overlay`) and debug signing key file from the supplied project so a build produced with the same key can update the existing installation. Keep a backup of your trade data before installing any new build.
