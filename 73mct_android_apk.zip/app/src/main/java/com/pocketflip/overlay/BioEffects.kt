package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.animation.LinearInterpolator
import android.widget.TextView
import kotlin.math.min

/** Animated text effects for the profile bio. Every effect uses your theme colors. */
object BioEffects {

    /** Applies [effect] to [tv] and returns the running animator (cancel it when you leave). */
    fun apply(tv: TextView, text: String, effect: String): ValueAnimator? {
        tv.paint.shader = null
        tv.setShadowLayer(0f, 0f, 0f, 0)
        val base = Theme.mix(Theme.muted, Theme.text, 0.55f)
        tv.setTextColor(base)
        tv.text = text
        if (text.isEmpty()) return null
        val density = tv.resources.displayMetrics.density

        return when (effect) {
            "shimmer" -> {
                val band = density * 220f
                val shader = LinearGradient(
                    0f, 0f, band, 0f,
                    intArrayOf(base, Theme.text, base), floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.REPEAT
                )
                val m = Matrix()
                tv.paint.shader = shader
                ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 2400
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        m.setTranslate((it.animatedValue as Float) * band, 0f)
                        shader.setLocalMatrix(m)
                        tv.invalidate()
                    }
                    start()
                }
            }
            "typewriter" -> {
                val n = text.length
                ValueAnimator.ofInt(0, n + 30).apply {
                    duration = (n * 55L + 1700L).coerceIn(1800L, 9000L)
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        val k = min(it.animatedValue as Int, n)
                        val sp = SpannableString(text)
                        if (k < n) {
                            sp.setSpan(
                                ForegroundColorSpan(Color.TRANSPARENT), k, n,
                                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                            )
                        }
                        tv.text = sp
                    }
                    start()
                }
            }
            "glow" -> {
                ValueAnimator.ofFloat(2f, 14f).apply {
                    duration = 1500
                    repeatCount = ValueAnimator.INFINITE
                    repeatMode = ValueAnimator.REVERSE
                    addUpdateListener {
                        tv.setShadowLayer(it.animatedValue as Float, 0f, 0f, Theme.alpha(Theme.text, 0xCC))
                    }
                    start()
                }
            }
            else -> null
        }
    }
}
