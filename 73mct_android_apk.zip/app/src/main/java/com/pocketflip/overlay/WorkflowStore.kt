package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Lightweight workflow memory for the floating trading panel.
 * Keeps research history separate from the paper-trading ledger so these features
 * cannot change balances, fills, or realized PnL.
 */
object WorkflowStore {
    data class RecentCoin(
        val ca: String,
        val name: String,
        val symbol: String,
        val imageUrl: String,
        val marketCap: Double,
        val initialMc: Double,
        val liquidityUsd: Double,
        val volume24h: Double,
        val priceUsd: Double,
        val firstSeenMs: Long,
        val lastSeenMs: Long,
        val peakMc: Double,
        val status: String,
        val decisionAtMs: Long
    ) {
        val researchDurationMs: Long
            get() = if (decisionAtMs > firstSeenMs && firstSeenMs > 0L) decisionAtMs - firstSeenMs else 0L
        val peakMultiple: Double
            get() = if (initialMc > 0.0) peakMc / initialMc else 0.0
    }

    data class PricePoint(val timeMs: Long, val marketCap: Double, val priceUsd: Double)

    private const val PREFS = "73mct_workflow_store"
    private const val KEY_RECENT = "recent_coins_v1"
    private const val KEY_FAST = "fast_mode_v1"
    private const val MAX_RECENT = 40
    private const val MAX_POINTS_PER_COIN = 180
    private const val SAMPLE_INTERVAL_MS = 4_000L

    private var prefs: SharedPreferences? = null
    private val recent = LinkedHashMap<String, RecentCoin>()
    private val lastSampleAt = HashMap<String, Long>()
    private val researchSessions = HashMap<String, Long>()
    private var lastRecentPersistAt = 0L

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try {
            val raw = prefs?.getString(KEY_RECENT, null) ?: return
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val ca = o.optString("ca", "")
                if (ca.isBlank()) continue
                recent[ca] = RecentCoin(
                    ca = ca,
                    name = o.optString("name", "Token"),
                    symbol = o.optString("symbol", "TOK"),
                    imageUrl = o.optString("imageUrl", ""),
                    marketCap = o.optDouble("marketCap", 0.0),
                    initialMc = o.optDouble("initialMc", o.optDouble("marketCap", 0.0)),
                    liquidityUsd = o.optDouble("liquidityUsd", 0.0),
                    volume24h = o.optDouble("volume24h", 0.0),
                    priceUsd = o.optDouble("priceUsd", 0.0),
                    firstSeenMs = o.optLong("firstSeenMs", 0L),
                    lastSeenMs = o.optLong("lastSeenMs", 0L),
                    peakMc = o.optDouble("peakMc", 0.0),
                    status = o.optString("status", "RECENT"),
                    decisionAtMs = o.optLong("decisionAtMs", 0L)
                )
            }
        } catch (_: Throwable) {
            recent.clear()
        }
    }

    @Synchronized
    fun isFastMode(): Boolean = prefs?.getBoolean(KEY_FAST, true) ?: true

    @Synchronized
    fun setFastMode(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_FAST, enabled)?.apply()
    }

    /** Records the latest token state and a sparse price history (one point every four seconds). */
    @Synchronized
    fun recordToken(token: TokenInfo, forceSnapshot: Boolean = false) {
        if (token.ca.isBlank()) return
        val now = System.currentTimeMillis()
        val old = recent[token.ca]
        recent.remove(token.ca)
        recent[token.ca] = RecentCoin(
            ca = token.ca,
            name = token.name.ifBlank { old?.name ?: "Token" },
            symbol = token.symbol.ifBlank { old?.symbol ?: "TOK" },
            imageUrl = token.imageUrl.ifBlank { old?.imageUrl ?: "" },
            marketCap = token.marketCap.takeIf { it > 0.0 } ?: (old?.marketCap ?: 0.0),
            initialMc = old?.initialMc?.takeIf { it > 0.0 } ?: token.marketCap,
            liquidityUsd = token.liquidityUsd.takeIf { it > 0.0 } ?: (old?.liquidityUsd ?: 0.0),
            volume24h = token.volume24h.takeIf { it > 0.0 } ?: (old?.volume24h ?: 0.0),
            priceUsd = token.priceUsd.takeIf { it > 0.0 } ?: (old?.priceUsd ?: 0.0),
            firstSeenMs = old?.firstSeenMs ?: now,
            lastSeenMs = now,
            peakMc = maxOf(old?.peakMc ?: 0.0, token.marketCap),
            status = old?.status ?: "RECENT",
            decisionAtMs = old?.decisionAtMs ?: 0L
        )
        while (recent.size > MAX_RECENT) {
            val oldest = recent.keys.firstOrNull() ?: break
            recent.remove(oldest)
        }
        if (forceSnapshot || now - lastRecentPersistAt >= SAMPLE_INTERVAL_MS) {
            persistRecent()
            lastRecentPersistAt = now
        }
        val last = lastSampleAt[token.ca] ?: 0L
        if (forceSnapshot || now - last >= SAMPLE_INTERVAL_MS) {
            appendPricePoint(token.ca, PricePoint(now, token.marketCap, token.priceUsd))
            lastSampleAt[token.ca] = now
        }
    }

    @Synchronized
    fun startResearch(ca: String) {
        if (ca.isNotBlank()) researchSessions[ca] = System.currentTimeMillis()
    }

    @Synchronized
    fun researchDurationMs(ca: String): Long {
        val start = researchSessions[ca] ?: recent[ca]?.firstSeenMs ?: return 0L
        return (System.currentTimeMillis() - start).coerceAtLeast(0L)
    }

    @Synchronized
    fun markDecision(ca: String, status: String): Long {
        val old = recent[ca] ?: return researchDurationMs(ca)
        val now = System.currentTimeMillis()
        val elapsed = researchDurationMs(ca)
        researchSessions.remove(ca)
        recent[ca] = old.copy(status = status, decisionAtMs = now)
        persistRecent()
        lastRecentPersistAt = now
        return elapsed
    }

    @Synchronized
    fun getRecent(): List<RecentCoin> = recent.values.toList().asReversed()

    @Synchronized
    fun getWatchlist(): List<RecentCoin> = recent.values.filter { it.status == "WATCH" }.toList().asReversed()

    @Synchronized
    fun getSkipped(): List<RecentCoin> = recent.values.filter { it.status == "SKIPPED" }.toList().asReversed()

    @Synchronized
    fun getPriceHistory(ca: String): List<PricePoint> {
        val raw = prefs?.getString(historyKey(ca), null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<PricePoint>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(PricePoint(o.optLong("t"), o.optDouble("mc"), o.optDouble("price")))
            }
            out
        } catch (_: Throwable) { emptyList() }
    }

    @Synchronized
    fun bestSkippedMultiple(): Pair<RecentCoin, Double>? {
        val best = getSkipped().filter { it.initialMc > 0.0 && it.peakMc > 0.0 }
            .maxByOrNull { it.peakMc / it.initialMc } ?: return null
        return best to (best.peakMc / best.initialMc)
    }

    private fun appendPricePoint(ca: String, point: PricePoint) {
        val p = prefs ?: return
        try {
            val arr = JSONArray(p.getString(historyKey(ca), "[]"))
            // Ignore duplicate/invalid values.
            if (point.marketCap <= 0.0 || point.marketCap.isNaN() || point.marketCap.isInfinite()) return
            arr.put(JSONObject().apply {
                put("t", point.timeMs)
                put("mc", point.marketCap)
                put("price", point.priceUsd)
            })
            while (arr.length() > MAX_POINTS_PER_COIN) {
                val trimmed = JSONArray()
                for (i in arr.length() - MAX_POINTS_PER_COIN until arr.length()) trimmed.put(arr.get(i))
                p.edit().putString(historyKey(ca), trimmed.toString()).apply()
                return
            }
            p.edit().putString(historyKey(ca), arr.toString()).apply()
        } catch (_: Throwable) {}
    }

    private fun historyKey(ca: String): String = "history_${ca}"

    private fun persistRecent() {
        val p = prefs ?: return
        val arr = JSONArray()
        recent.values.forEach { item ->
            arr.put(JSONObject().apply {
                put("ca", item.ca)
                put("name", item.name)
                put("symbol", item.symbol)
                put("imageUrl", item.imageUrl)
                put("marketCap", item.marketCap)
                put("initialMc", item.initialMc)
                put("liquidityUsd", item.liquidityUsd)
                put("volume24h", item.volume24h)
                put("priceUsd", item.priceUsd)
                put("firstSeenMs", item.firstSeenMs)
                put("lastSeenMs", item.lastSeenMs)
                put("peakMc", item.peakMc)
                put("status", item.status)
                put("decisionAtMs", item.decisionAtMs)
            })
        }
        p.edit().putString(KEY_RECENT, arr.toString()).apply()
    }
}
