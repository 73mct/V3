package com.pocketflip.overlay

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Best-effort Solana token concentration estimate using public JSON-RPC.
 * Aggregates the 20 largest token accounts by their owner wallet where parsed account
 * metadata is available. This is not a full all-holder index and is labelled as an estimate.
 */
object HolderScanner {
    data class Snapshot(
        val top10Pct: Double,
        val largestOwnerPct: Double,
        val walletsObserved: Int,
        val updatedAtMs: Long
    )

    private data class Cached(val snapshot: Snapshot, val savedAtMs: Long)
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.SECONDS)
        .build()
    private val executor = Executors.newFixedThreadPool(2)
    private val cache = ConcurrentHashMap<String, Cached>()
    private val inFlight = ConcurrentHashMap<String, MutableList<(Snapshot?) -> Unit>>()
    private val lock = Any()
    private val rpcUrls = listOf(
        "https://api.mainnet-beta.solana.com",
        "https://solana-rpc.publicnode.com"
    )

    fun fetch(ca: String, callback: (Snapshot?) -> Unit) {
        if (ca.isBlank()) { callback(null); return }
        val cached = cache[ca]
        if (cached != null && System.currentTimeMillis() - cached.savedAtMs < 60_000L) {
            callback(cached.snapshot)
            return
        }
        synchronized(lock) {
            val waiting = inFlight[ca]
            if (waiting != null) {
                waiting.add(callback)
                return
            }
            inFlight[ca] = mutableListOf(callback)
        }
        executor.execute {
            val snapshot = scan(ca)
            if (snapshot != null) cache[ca] = Cached(snapshot, System.currentTimeMillis())
            val callbacks = synchronized(lock) { inFlight.remove(ca)?.toList() ?: emptyList() }
            callbacks.forEach { cb -> try { cb(snapshot) } catch (_: Throwable) {} }
        }
    }

    private fun scan(mint: String): Snapshot? {
        for (url in rpcUrls) {
            try {
                val largest = rpc(url, "getTokenLargestAccounts", JSONArray().put(mint).put(JSONObject().put("commitment", "confirmed")))
                    ?: continue
                val accounts = largest.optJSONArray("value") ?: continue
                if (accounts.length() == 0) continue
                val accountAddresses = JSONArray()
                val tokenAccountAmounts = HashMap<String, Double>()
                for (i in 0 until accounts.length()) {
                    val item = accounts.optJSONObject(i) ?: continue
                    val address = item.optString("address", "")
                    val amount = item.optString("amount", "0").toDoubleOrNull() ?: 0.0
                    if (address.isNotBlank()) {
                        accountAddresses.put(address)
                        tokenAccountAmounts[address] = amount
                    }
                }
                if (accountAddresses.length() == 0) continue

                val supplyResult = rpc(url, "getTokenSupply", JSONArray().put(mint).put(JSONObject().put("commitment", "confirmed")))
                    ?.optJSONObject("value")
                val supplyRaw = supplyResult?.optString("amount", "0")?.toDoubleOrNull() ?: 0.0
                if (supplyRaw <= 0.0) continue

                val multiple = rpc(url, "getMultipleAccounts", JSONArray().put(accountAddresses).put(JSONObject().put("encoding", "jsonParsed").put("commitment", "confirmed")))
                val accountValues = multiple?.optJSONArray("value")
                val ownerTotals = HashMap<String, Double>()
                for (i in 0 until accountAddresses.length()) {
                    val address = accountAddresses.optString(i)
                    val parsedAccount = accountValues?.optJSONObject(i)
                        ?.optJSONObject("data")?.optJSONObject("parsed")?.optJSONObject("info")
                    val owner = parsedAccount?.optString("owner", "")?.takeIf { it.isNotBlank() } ?: continue
                    ownerTotals[owner] = (ownerTotals[owner] ?: 0.0) + (tokenAccountAmounts[address] ?: 0.0)
                }
                if (ownerTotals.isEmpty()) continue
                val sorted = ownerTotals.values.sortedDescending()
                val top10 = sorted.take(10).sum() / supplyRaw * 100.0
                val largestOwner = sorted.first() / supplyRaw * 100.0
                return Snapshot(
                    top10Pct = top10.coerceIn(0.0, 100.0),
                    largestOwnerPct = largestOwner.coerceIn(0.0, 100.0),
                    walletsObserved = ownerTotals.size,
                    updatedAtMs = System.currentTimeMillis()
                )
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun rpc(url: String, method: String, params: JSONArray): JSONObject? {
        val payload = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", method)
            put("params", params)
        }
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).post(body).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val text = response.body?.string() ?: return null
            val result = JSONObject(text)
            if (result.has("error")) return null
            return result.optJSONObject("result")
        }
    }
}
