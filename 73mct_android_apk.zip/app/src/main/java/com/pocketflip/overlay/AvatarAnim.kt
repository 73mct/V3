package com.pocketflip.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Movie
import android.graphics.drawable.Animatable2
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import kotlin.math.max

/**
 * Gives the PnL card your profile picture at any moment in time.
 * GIFs are played with their own timeline, so the exported MP4 shows the real animation.
 * Animated WebP is captured once into small frames. A still picture is just returned as is.
 * Read only: it never changes the saved picture.
 */
object AvatarAnim {
    private const val SIZE = 240
    private const val STEP_MS = 40L

    @Volatile
    private var still: Bitmap? = null
    private var movie: Movie? = null
    private var movieW = 0
    private var movieH = 0
    private var gifMs = 0

    @Volatile
    private var webpFrames: List<Bitmap> = emptyList()
    private val cache = HashMap<Int, Bitmap>()

    val isAnimated: Boolean
        get() = gifMs > 0 || webpFrames.size > 1

    /** Reads the saved profile picture. Call off the main thread. Returns true if there is a picture. */
    @Suppress("DEPRECATION")
    @Synchronized
    fun load(context: Context): Boolean {
        ProfileStore.init(context)
        still = null
        movie = null
        gifMs = 0
        webpFrames = emptyList()
        cache.clear()
        val f = ProfileStore.imageFile("avatar") ?: return false
        if (!f.exists()) return false
        try {
            val head = ByteArray(16)
            val n = f.inputStream().use { it.read(head) }
            val sig = if (n >= 6) String(head, 0, 6, Charsets.ISO_8859_1) else ""
            if (sig.startsWith("GIF8")) {
                val m = Movie.decodeFile(f.absolutePath)
                if (m != null && m.width() > 0 && m.height() > 0) {
                    movie = m
                    movieW = m.width()
                    movieH = m.height()
                    gifMs = m.duration()
                    still = drawMovie(m, 0)
                }
            }
        } catch (_: Throwable) {
            movie = null
            gifMs = 0
        }
        if (still == null) {
            // Any other picture (PNG, JPG, WebP): the first frame is read by the normal decoder.
            try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.absolutePath, bounds)
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
                val real = BitmapFactory.Options()
                real.inSampleSize = sample
                val b = BitmapFactory.decodeFile(f.absolutePath, real)
                if (b != null) still = cropSquare(b)
            } catch (_: Throwable) {
            }
        }
        return still != null
    }

    private fun cropSquare(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = max(SIZE.toFloat() / src.width, SIZE.toFloat() / src.height)
        val w = src.width * s
        val h = src.height * s
        val dst = android.graphics.RectF((SIZE - w) / 2f, (SIZE - h) / 2f, (SIZE + w) / 2f, (SIZE + h) / 2f)
        c.drawBitmap(src, null, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        return out
    }

    @Suppress("DEPRECATION")
    private fun drawMovie(m: Movie, timeMs: Int): Bitmap {
        val b = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val s = max(SIZE.toFloat() / movieW, SIZE.toFloat() / movieH)
        c.translate((SIZE - movieW * s) / 2f, (SIZE - movieH * s) / 2f)
        c.scale(s, s)
        m.setTime(timeMs)
        m.draw(c, 0f, 0f)
        return b
    }

    /** The picture at [timeMs] into the clip. Time 0 (the PNG) or animate = false gives the still picture. */
    @Synchronized
    fun frameAt(timeMs: Long, animate: Boolean): Bitmap? {
        if (!animate || timeMs <= 0L) return still
        val m = movie
        if (m != null && gifMs > 0) {
            val key = ((timeMs % gifMs) / STEP_MS).toInt()
            val hit = cache[key]
            if (hit != null) return hit
            return try {
                val b = drawMovie(m, (key * STEP_MS).toInt().coerceAtMost(gifMs - 1))
                if (cache.size > 90) cache.clear()
                cache[key] = b
                b
            } catch (_: Throwable) {
                still
            }
        }
        val w = webpFrames
        if (w.size > 1) return w[((timeMs / STEP_MS) % w.size).toInt()]
        return still
    }

    // ------------------------------------------------------------------
    // Animated WebP: play it once on the main thread and keep small frames
    // ------------------------------------------------------------------

    /** Call on the main thread. Does nothing for GIFs, stills or Android older than 9. */
    fun captureWebp(context: Context, onDone: () -> Unit) {
        if (Build.VERSION.SDK_INT < 28) return
        if (movie != null) return
        val f = ProfileStore.imageFile("avatar") ?: return
        if (!f.exists()) return
        try {
            val head = ByteArray(128)
            val n = f.inputStream().use { it.read(head) }
            if (n < 20) return
            val riff = String(head, 0, 4, Charsets.ISO_8859_1)
            val webp = String(head, 8, 4, Charsets.ISO_8859_1)
            val anim = String(head, 0, n, Charsets.ISO_8859_1).contains("ANIM")
            if (riff != "RIFF" || webp != "WEBP" || !anim) return
            captureApi28(f, onDone)
        } catch (_: Throwable) {
        }
    }

    @android.annotation.TargetApi(28)
    private fun captureApi28(f: File, onDone: () -> Unit) {
        val src = ImageDecoder.createSource(f)
        val d: Drawable = ImageDecoder.decodeDrawable(src, ImageDecoder.OnHeaderDecodedListener { decoder, info, _ ->
            val longest = max(info.size.width, info.size.height)
            var k = 1
            while (longest / k > 320) k *= 2
            if (k > 1) decoder.setTargetSampleSize(k)
        })
        val a = d as? AnimatedImageDrawable ?: return
        val iw = if (a.intrinsicWidth > 0) a.intrinsicWidth else SIZE
        val ih = if (a.intrinsicHeight > 0) a.intrinsicHeight else SIZE
        a.setBounds(0, 0, iw, ih)
        a.repeatCount = 0
        val frames = ArrayList<Bitmap>()
        val h = Handler(Looper.getMainLooper())
        var finished = false
        a.registerAnimationCallback(object : Animatable2.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                finished = true
            }
        })
        val started = System.currentTimeMillis()
        val tick = object : Runnable {
            override fun run() {
                try {
                    val over = finished || frames.size >= 150 || System.currentTimeMillis() - started > 7000L
                    if (!over) {
                        val b = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
                        val c = Canvas(b)
                        val s = max(SIZE.toFloat() / iw, SIZE.toFloat() / ih)
                        c.translate((SIZE - iw * s) / 2f, (SIZE - ih * s) / 2f)
                        c.scale(s, s)
                        a.draw(c)
                        frames.add(b)
                        h.postDelayed(this, STEP_MS)
                        return
                    }
                    a.stop()
                    if (frames.size > 1) {
                        synchronized(AvatarAnim) {
                            webpFrames = frames
                            cache.clear()
                        }
                        onDone()
                    }
                } catch (_: Throwable) {
                }
            }
        }
        a.start()
        h.post(tick)
    }
}
