package com.pocketflip.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.LruCache
import android.widget.ImageView
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Finds a coin's picture by its CA, with several backup sources, and remembers it on disk.
 * This is a separate helper: it does not touch DexScreenerClient (price feed) at all.
 *
 * Order: your own picture -> saved copy -> DexScreener image -> the coin's on-chain metadata
 * -> pump.fun -> GeckoTerminal -> Jupiter -> DexScreener CDN.
 * If everything fails the UI shows a letter circle, and you can tap the circle to pick a picture yourself.
 */
object CoinImages {

    private class Source(val label: String, val fetch: () -> ByteArray?)

    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val mem = LruCache<String, Bitmap>(64)
    private val sources = ConcurrentHashMap<String, String>()
    private val lastFail = ConcurrentHashMap<String, Long>()
    private val waiting = HashMap<String, MutableList<(Bitmap?) -> Unit>>()

    @Volatile
    private var dir: File? = null

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private const val METADATA_PROGRAM = "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
    private const val B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    private val IPFS_GATEWAYS = listOf(
        "https://ipfs.io/ipfs/",
        "https://gateway.pinata.cloud/ipfs/",
        "https://nftstorage.link/ipfs/"
    )
    private val RPCS = listOf("https://solana-rpc.publicnode.com", "https://api.mainnet-beta.solana.com")

    fun init(context: Context) {
        if (dir != null) return
        val d = File(context.applicationContext.filesDir, "coin_images")
        d.mkdirs()
        dir = d
    }

    /** Which source gave the picture for this coin (empty if none yet). Shown in the trade detail. */
    fun sourceOf(ca: String): String = sources[ca] ?: ""

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    /** Loads the picture in the background. [cb] may be called on any thread. */
    fun load(ca: String, dexUrl: String, cb: (Bitmap?) -> Unit) {
        val key = if (ca.isNotEmpty()) ca else dexUrl
        if (key.isEmpty()) {
            cb(null)
            return
        }
        val hit = mem.get(key)
        if (hit != null) {
            cb(hit)
            return
        }
        var alreadyRunning = false
        synchronized(waiting) {
            val list = waiting[key]
            if (list != null) {
                list.add(cb)
                alreadyRunning = true
            } else {
                waiting[key] = mutableListOf(cb)
            }
        }
        if (alreadyRunning) return
        pool.execute {
            var bmp: Bitmap? = null
            try {
                bmp = resolve(key, ca, dexUrl)
            } catch (_: Throwable) {
            }
            if (bmp != null) mem.put(key, bmp)
            val callbacks: List<(Bitmap?) -> Unit> = synchronized(waiting) {
                val l = waiting.remove(key)
                val copy = ArrayList<(Bitmap?) -> Unit>()
                if (l != null) copy.addAll(l)
                copy
            }
            for (f in callbacks) {
                try {
                    f(bmp)
                } catch (_: Throwable) {
                }
            }
        }
    }

    /** Puts a letter circle in [iv] right away, then swaps in the real picture when it is found. */
    fun bind(iv: ImageView, ca: String, symbol: String, dexUrl: String, onDone: ((Bitmap?) -> Unit)? = null) {
        iv.tag = ca
        val key = if (ca.isNotEmpty()) ca else dexUrl
        val hit = if (key.isEmpty()) null else mem.get(key)
        if (hit != null) {
            // already known: show it instantly (no letter flash while the screen refreshes)
            iv.setImageBitmap(hit)
            onDone?.invoke(hit)
            return
        }
        iv.setImageBitmap(letterBitmap(symbol))
        load(ca, dexUrl) { bmp ->
            main.post {
                if (iv.tag == ca) {
                    if (bmp != null) iv.setImageBitmap(bmp)
                    onDone?.invoke(bmp)
                }
            }
        }
    }

    /** Saves a picture you picked yourself for this coin (used everywhere from now on). */
    fun setCustom(ca: String, bmp: Bitmap) {
        val d = dir ?: return
        try {
            FileOutputStream(File(d, "custom_" + safe(ca))).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            lastFail.clear()
            mem.put(ca, bmp)
            sources[ca] = "your picture"
        } catch (_: Throwable) {
        }
    }

    fun letterBitmap(symbol: String): Bitmap {
        val letter = symbol.trimStart('$').take(1).uppercase().ifEmpty { "?" }
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = LinearGradient(
            0f, 0f, 0f, size.toFloat(),
            Theme.alpha(Theme.text, 80), Theme.alpha(Theme.text, 28), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Theme.text
        tp.textSize = size * 0.5f
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        tp.textAlign = Paint.Align.CENTER
        val y = size / 2f - (tp.descent() + tp.ascent()) / 2f
        c.drawText(letter, size / 2f, y, tp)
        return bmp
    }

    // ------------------------------------------------------------------
    // Resolving
    // ------------------------------------------------------------------

    private fun safe(s: String): String = s.filter { it.isLetterOrDigit() }.take(80)

    private fun resolve(key: String, ca: String, dexUrl: String): Bitmap? {
        val d = dir
        val name = safe(key)
        if (d != null) {
            val custom = File(d, "custom_$name")
            if (custom.exists()) {
                val b = decode(custom.readBytes())
                if (b != null) {
                    sources[key] = "your picture"
                    return b
                }
            }
            val cached = File(d, "img_$name")
            if (cached.exists()) {
                val b = decode(cached.readBytes())
                if (b != null) {
                    if (sources[key] == null) sources[key] = "saved copy"
                    return b
                }
            }
        }
        val failKey = key + "|" + dexUrl
        val lf = lastFail[failKey]
        if (lf != null && System.currentTimeMillis() - lf < 40_000L) return null

        val tries = ArrayList<Source>()
        if (dexUrl.isNotEmpty()) tries.add(Source("DexScreener") { download(dexUrl) })
        if (ca.isNotEmpty()) {
            tries.add(Source("on-chain metadata") { fromChainMetadata(ca) })
            tries.add(Source("pump.fun") { fromPumpFun(ca) })
            tries.add(Source("GeckoTerminal") { fromGecko(ca) })
            tries.add(Source("Jupiter") { fromJupiter(ca) })
            tries.add(Source("DexScreener CDN") { download("https://dd.dexscreener.com/ds-data/tokens/solana/$ca.png") })
        }
        for (t in tries) {
            val bytes: ByteArray? = try {
                t.fetch()
            } catch (_: Throwable) {
                null
            }
            if (bytes == null) continue
            val bmp = decode(bytes)
            if (bmp == null) continue
            sources[key] = t.label
            if (d != null) {
                try {
                    File(d, "img_$name").writeBytes(bytes)
                } catch (_: Throwable) {
                }
            }
            return bmp
        }
        lastFail[failKey] = System.currentTimeMillis()
        return null
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        return try {
            val b = BitmapFactory.Options()
            b.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, b)
            if (b.outWidth <= 0 || b.outHeight <= 0) return null
            var sample = 1
            while (b.outWidth / sample > 640 || b.outHeight / sample > 640) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        } catch (_: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------
    // Network helpers
    // ------------------------------------------------------------------

    private fun fixUrl(u: String): String {
        val t = u.trim()
        return if (t.startsWith("ipfs://")) {
            "https://ipfs.io/ipfs/" + t.removePrefix("ipfs://").removePrefix("ipfs/")
        } else {
            t
        }
    }

    private fun get(url: String): ByteArray? {
        return try {
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 14) 73MCT").build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) {
                    null
                } else {
                    val body = r.body
                    if (body == null || body.contentLength() > 8_000_000L) null else body.bytes()
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun download(url: String): ByteArray? {
        if (url.isBlank()) return null
        val fixed = fixUrl(url)
        val urls = ArrayList<String>()
        urls.add(fixed)
        val idx = fixed.indexOf("/ipfs/")
        if (idx >= 0) {
            val path = fixed.substring(idx + 6)
            for (g in IPFS_GATEWAYS) {
                val u = g + path
                if (u != fixed) urls.add(u)
            }
        }
        for (u in urls) {
            val r = get(u)
            if (r != null) return r
        }
        return null
    }

    private fun getText(url: String): String? {
        val b = get(fixUrl(url)) ?: return null
        return String(b, Charsets.UTF_8)
    }

    private fun fromMetadataJson(uri: String): ByteArray? {
        val txt = getText(uri)
        if (txt == null) {
            // IPFS metadata files: try the other gateways too
            val idx = uri.indexOf("/ipfs/")
            if (idx >= 0) {
                val path = uri.substring(idx + 6)
                for (g in IPFS_GATEWAYS) {
                    val t2 = getText(g + path)
                    if (t2 != null) return imageFromJson(t2)
                }
            }
            return null
        }
        return imageFromJson(txt)
    }

    private fun imageFromJson(txt: String): ByteArray? {
        val o = JSONObject(txt)
        var img = o.optString("image", "")
        if (img.isEmpty()) img = o.optString("image_uri", "")
        if (img.isEmpty()) return null
        return download(img)
    }

    private fun fromPumpFun(ca: String): ByteArray? {
        val bases = listOf("https://frontend-api-v3.pump.fun/coins/", "https://frontend-api.pump.fun/coins/")
        for (base in bases) {
            val js: String? = getText(base + ca)
            if (js == null) continue
            val o = JSONObject(js)
            val img = o.optString("image_uri", "")
            if (img.isNotEmpty()) {
                val b = download(img)
                if (b != null) return b
            }
            val meta = o.optString("metadata_uri", "")
            if (meta.isNotEmpty()) {
                val b = fromMetadataJson(meta)
                if (b != null) return b
            }
        }
        return null
    }

    private fun fromGecko(ca: String): ByteArray? {
        val js = getText("https://api.geckoterminal.com/api/v2/networks/solana/tokens/$ca") ?: return null
        val attr = JSONObject(js).optJSONObject("data")?.optJSONObject("attributes") ?: return null
        val img = attr.optString("image_url", "")
        if (img.isEmpty() || img == "null" || img.contains("missing")) return null
        return download(img)
    }

    private fun fromJupiter(ca: String): ByteArray? {
        val js = getText("https://lite-api.jup.ag/tokens/v2/search?query=$ca")
        if (js != null) {
            try {
                val arr = JSONArray(js)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("id", "") == ca) {
                        val ic = o.optString("icon", "")
                        if (ic.isNotEmpty()) {
                            val b = download(ic)
                            if (b != null) return b
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }
        val js2 = getText("https://tokens.jup.ag/token/$ca") ?: return null
        val logo = JSONObject(js2).optString("logoURI", "")
        if (logo.isEmpty()) return null
        return download(logo)
    }

    // ------------------------------------------------------------------
    // On-chain metadata (the link every token stores about itself)
    // ------------------------------------------------------------------

    /** Plain text of a web page / JSON (used by the link finder). */
    fun fetchText(url: String): String? = try { getText(url) } catch (_: Throwable) { null }

    /** The coin's on-chain metadata JSON as text (it often holds the X, Telegram and website links). */
    fun chainMetadataText(ca: String): String? {
        return try {
            val mint = b58decode(ca)
            if (mint.size != 32) return null
            val pda = metadataPda(mint) ?: return null
            val data = rpcAccountData(pda) ?: return null
            val uri = parseMetadataUri(data) ?: return null
            if (uri.isEmpty()) return null
            val txt = getText(uri)
            if (txt != null) return txt
            val idx = uri.indexOf("/ipfs/")
            if (idx >= 0) {
                val path = uri.substring(idx + 6)
                for (g in IPFS_GATEWAYS) {
                    val t2 = getText(g + path)
                    if (t2 != null) return t2
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun fromChainMetadata(ca: String): ByteArray? {
        val mint = b58decode(ca)
        if (mint.size != 32) return null
        val pda = metadataPda(mint) ?: return null
        val data = rpcAccountData(pda) ?: return null
        val uri = parseMetadataUri(data) ?: return null
        if (uri.isEmpty()) return null
        return fromMetadataJson(uri)
    }

    private fun rpcAccountData(addr: String): ByteArray? {
        val body = "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"getAccountInfo\",\"params\":[\"$addr\",{\"encoding\":\"base64\"}]}"
        for (url in RPCS) {
            try {
                val req = Request.Builder().url(url)
                    .post(body.toRequestBody("application/json".toMediaType())).build()
                var result: ByteArray? = null
                http.newCall(req).execute().use { r ->
                    if (r.isSuccessful) {
                        val txt = r.body?.string() ?: ""
                        val v = JSONObject(txt).optJSONObject("result")?.optJSONObject("value")
                        val arr = v?.optJSONArray("data")
                        if (arr != null && arr.length() > 0) {
                            result = Base64.decode(arr.getString(0), Base64.DEFAULT)
                        }
                    }
                }
                if (result != null) return result
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun parseMetadataUri(data: ByteArray): String? {
        var o = 65 // key (1) + update authority (32) + mint (32)
        fun readStr(): String? {
            if (o + 4 > data.size) return null
            val len = (data[o].toInt() and 0xFF) or
                ((data[o + 1].toInt() and 0xFF) shl 8) or
                ((data[o + 2].toInt() and 0xFF) shl 16) or
                ((data[o + 3].toInt() and 0xFF) shl 24)
            o += 4
            if (len < 0 || o + len > data.size) return null
            val s = String(data, o, len, Charsets.UTF_8)
            o += len
            return s.trim { it == '\u0000' || it.isWhitespace() }
        }
        if (readStr() == null) return null // name
        if (readStr() == null) return null // symbol
        return readStr()
    }

    private val P: BigInteger = BigInteger.ONE.shiftLeft(255).subtract(BigInteger.valueOf(19))
    private val D: BigInteger by lazy {
        BigInteger.valueOf(-121665).mod(P).multiply(BigInteger.valueOf(121666).modInverse(P)).mod(P)
    }

    private fun isOnCurve(h: ByteArray): Boolean {
        val rev = ByteArray(32)
        for (i in 0 until 32) rev[i] = h[31 - i]
        rev[0] = (rev[0].toInt() and 0x7F).toByte()
        val yv = BigInteger(1, rev)
        if (yv.compareTo(P) >= 0) return false
        val y2 = yv.multiply(yv).mod(P)
        val u = y2.subtract(BigInteger.ONE).mod(P)
        val v = D.multiply(y2).add(BigInteger.ONE).mod(P)
        val x2 = u.multiply(v.modInverse(P)).mod(P)
        if (x2.signum() == 0) return true
        val e = P.subtract(BigInteger.ONE).shiftRight(1)
        return x2.modPow(e, P) == BigInteger.ONE
    }

    private fun metadataPda(mint: ByteArray): String? {
        val program = b58decode(METADATA_PROGRAM)
        val seed = "metadata".toByteArray(Charsets.UTF_8)
        val tail = "ProgramDerivedAddress".toByteArray(Charsets.UTF_8)
        for (bump in 255 downTo 0) {
            val md = MessageDigest.getInstance("SHA-256")
            md.update(seed)
            md.update(program)
            md.update(mint)
            md.update(byteArrayOf(bump.toByte()))
            md.update(program)
            md.update(tail)
            val h = md.digest()
            if (!isOnCurve(h)) return b58encode(h)
        }
        return null
    }

    private fun b58decode(s: String): ByteArray {
        var n = BigInteger.ZERO
        val base = BigInteger.valueOf(58)
        for (ch in s) {
            val i = B58.indexOf(ch)
            if (i < 0) throw IllegalArgumentException("bad base58")
            n = n.multiply(base).add(BigInteger.valueOf(i.toLong()))
        }
        var zeros = 0
        for (ch in s) {
            if (ch == '1') zeros++ else break
        }
        var body = ByteArray(0)
        if (n.signum() > 0) {
            body = n.toByteArray()
            if (body.size > 1 && body[0] == 0.toByte()) body = body.copyOfRange(1, body.size)
        }
        val out = ByteArray(zeros + body.size)
        System.arraycopy(body, 0, out, zeros, body.size)
        return out
    }

    private fun b58encode(data: ByteArray): String {
        var n = BigInteger(1, data)
        val base = BigInteger.valueOf(58)
        val sb = StringBuilder()
        while (n.signum() > 0) {
            val qr = n.divideAndRemainder(base)
            sb.append(B58[qr[1].toInt()])
            n = qr[0]
        }
        for (b in data) {
            if (b.toInt() == 0) sb.append('1') else break
        }
        return sb.reverse().toString()
    }
}
